import os

def olustur_klasorler(sonuclar_klasoru, id_klasoru):
    # Sonuç klasörünü oluştur
    if not os.path.exists(sonuclar_klasoru):
        os.makedirs(sonuclar_klasoru)

    # 'id' klasörünü oluştur
    if not os.path.exists(id_klasoru):
        os.makedirs(id_klasoru)

def process_tool1():
    klasor_adi = "BigData"
    sonuclar_klasoru = "CheckLog"
    id_klasoru = os.path.join(sonuclar_klasoru, "id")

    olustur_klasorler(sonuclar_klasoru, id_klasoru)

    eklenen_domain_listesi = [
"antmediahost.com",
"ardhosting.com",
"atriumhosting.com",
"boc.co.id",
"bosen.net",
"buycloud.id",
"cbtp.co.id",
"cirebonhosting.net",
"citrahost.com",
"cloudkilat.com",
"connectindo.com",
"daxa.net",
"dedoho.pw",
"dewabiz.com",
"dhyhost.com",
"dijaminmurah.com",
"earhost.biz",
"eliteweb.co.id",
"flazznetworks.com",
"galuhweb.com",
"goldenfast.net",
"herza.id",
"hostarmada.com",
"hosteko.com",
"hostingan.id",
"hostingpangeran.co.id",
"hostingtangguh.com",
"hostnic.id",
"permana.net.id",
"idgx.net",
"idebagus.com",
"idreg.net",
"idroot.com",
"idwebhost.com",
"idwebspace.com",
"iixmedia.com",
"indocenter.co.id",
"indoglobal.com",
"indosite.com",
"indositehost.com",
"indowebsite.co.id",
"jagoancloud.com",
"jagoanhosting.com",
"jakhoster.com",
"jayahost.com",
"jetdino.com",
"jetorbit.com",
"jogloitcenter.com",
"kiosdomain.com",
"klikserver.com",
"kuncihost.com",
"liquidwebspace.com",
"mebiso.com",
"medanhosting.co.id",
"menyohost.com",
"mikyhost.com",
"neohoster.com",
"members.nusa.id",
"nusantaradatacenter.com",
"pasarhosting.com",
"plasawebhost.com",
"plikhost.com",
"pusathosting.com",
"qwebs.id",
"qwords.com",
"rackh.com",
"rajwebhost.com",
"readyspace.co.id",
"riaucybersolution.net",
"rumahhosting.com",
"satelitweb.com",
"serayahost.com",
"shehoster.com",
"smarteksistem.com",
"sorabit.com",
"telkomhosting.com",
"ultahost.com",
"quinjet.web.id",
"warnahost.com",
"web.z.com",
"whplus.com",
"winnervps.com",
"vpsblocks.com.au",
    ]
    process_domains(eklenen_domain_listesi, klasor_adi, id_klasoru)

def process_tool2():
    klasor_adi = "BigData"
    sonuclar_klasoru = "CheckLog"
    id_klasoru = os.path.join(sonuclar_klasoru, "in")

    olustur_klasorler(sonuclar_klasoru, id_klasoru)

    eklenen_domain_listesi = [
"24x7servermanagement.com",
"aheadhostllc.com",
"allserversolution.com",
"ariseserver.com",
"bagful.net",
"basezap.com",
"bigboxhost.com",
"bigrock.in",
"bluehost.in",
"brainpulse.com",
"buycheaprdp.com",
"cantech.in",
"cheapohosting.com",
"chociz.com",
"cloudminister.com",
"cloudoye.com",
"cloudtechtiq.com",
"ctrls.com",
"delhiwebhosting.co.in",
"desivps.com",
"domainindia.com",
"domainracer.com",
"dotzo.net",
"e2enetworks.com",
"esds.co.in",
"esteemhost.com",
"everdata.com",
"ewallhost.com",
"ewebguru.com",
"ezerhost.com",
"fastwebhost.in",
"globaliweb.com",
"globehost.com",
"glosting.com",
"hapihhost.in",
"hellomails.com",
"hioxindia.com",
"host.co.in",
"hostathash.com",
"hostbet.in",
"hostdime.in",
"hostgator.in",
"hostinghome.in",
"hostinginindia.com",
"hostingproviderindia.com",
"hostingraja.in",
"hostitsmart.com",
"hostmycode.in",
"hostnamaste.com",
"hostonnet.com",
"hostperl.com",
"hostrain.in",
"hostripples.com",
"i2k2.com",
"ideastack.com",
"impulseweb.net",
"infinitivehost.com",
"infinityhosts.com",
"it4int.com",
"jinfo.net",
"leapswitch.com",
"logicboxes.com",
"maxcloudhost.com",
"medhacloud.com",
"milesweb.com",
"mrcloudhosting.com",
"myglobalhost.in",
"natsav.com",
"netforchoice.com",
"netspaceindia.com",
"nettigritty.com",
"onliveserver.com",
"oxtrys.com",
"packwebhosting.com",
"parkinhost.com",
"prahost.com",
"prohosty.com",
"prolimehost.com",
"rackbank.com",
"razorhost.in",
"redserverhost.com",
"resellerclub.com",
"rovity.io",
"royalclouds.net",
"serverbasket.com",
"serverguy.com",
"serverwala.com",
"siliconhouse.net",
"squarebrothers.com",
"trafficpullz.com",
"ucartz.com",
"veeble.org",
"vps9.net",
"webcomindia.net",
"webeyesoft.com",
"webji.in",
"webwerks.in",
"wiplon.com",
"youstable.com",
"znetlive.com",
    ]
    process_domains(eklenen_domain_listesi, klasor_adi, id_klasoru)

def process_tool3():
    klasor_adi = "BigData"
    sonuclar_klasoru = "CheckLog"
    id_klasoru = os.path.join(sonuclar_klasoru, "th")

    olustur_klasorler(sonuclar_klasoru, id_klasoru)

    eklenen_domain_listesi = [
"21st-thailand.com",
"aplushosting.asia",
"bangmod.cloud",
"bestinternet.co.th",
"chaiyohosting.com",
"codeorange.co.th",
"colothai.com",
"coolhostplus.net",
"datatan.net",
"de.co.th",
"deedeehost.com",
"dotarai.co.th",
"dotsiam.com",
"dragonhispeed.com",
"hostatom.com",
"hostinglotus.com",
"hostneverdie.com",
"hostpacific.com",
"hostyim.com",
"ibiz.co.th",
"ic-myhost.com",
"idcthailand.co.th",
"igetweb.com",
"ihotvps.com",
"issp.co.th",
"jvh.co.th",
"metrabyte.cloud",
"modoeye.com",
"nakhonitech.com",
"netdesignhost.com",
"netregis.com",
"netway.co.th",
"nineweb.co.th",
"pathosting.co.th",
"porar.com",
"readyidc.com",
"servebase.co.th",
"servenet.co.th",
"servertoday.com",
"thaidatahosting.com",
"thaidomainhosting.com",
"thaieasyvps.com",
"thaihosting.asia",
"thaiprowebhosting.com",
"thaisite.net",
"thaitumweb.com",
"thaizone.com",
"thnic.co.th",
"vhostweb.com",
"vpshispeed.com",
"vwt.net",
"yourconnect.com",
    ]
    process_domains(eklenen_domain_listesi, klasor_adi, id_klasoru)

def process_tool4():
    klasor_adi = "BigData"
    sonuclar_klasoru = "CheckLog"
    id_klasoru = os.path.join(sonuclar_klasoru, "br")

    olustur_klasorler(sonuclar_klasoru, id_klasoru)

    eklenen_domain_listesi = [
"24horasonline.com.br",
"advancehost.com.br",
"argohost.net",
"asaweb.com.br",
"atmunhost.com.br",
"b2bhost.com.br",
"babidoos.com.br",
"bem-vindo.net",
"bhostbrasil.com.br",
"bhservers.com.br",
"bhsite.com.br",
"brasilcloud.com.br",
"brasilnaweb.com.br",
"brasilwebhost.com.br",
"brs.com.br",
"cdznet.com.br",
"datavirtua.com.br",
"dialhost.com.br",
"dokehost.com.br",
"ecxon.com.br",
"eivus.com",
"eveo.com.br",
"gospelidea.com",
"grupomeb.com.br",
"homehost.com.br",
"hospedagemsegura.com.br",
"hospedaria.com.br",
"host4.com.br",
"hostbits.com.br",
"hostdime.com.br",
"hostflix.com.br",
"hostgator.com.br",
"hostinger.com.br",
"hostmach.com.br",
"hostmidia.com.br",
"hostnet.com.br",
"hostone.com.br",
"hostsys.com.br",
"hostzone.com.br",
"hotlink.com.br",
"hyperfilter.com",
"innovahost.com.br",
"integrator.com.br",
"inweb.com.br",
"ipglobe.net",
"iphotel.com.br",
"isbrasil.info",
"itmnetworks.com.br",
"joinvix.com.br",
"k2host.com.br",
"king.host",
"latitude.sh",
"lgvhost.com.br",
"locahost.com.br",
"locamega.com.br",
"locaweb.com.br",
"mco2.com.br",
"mdhospeda.com",
"megahost.com.br",
"megaprovedor.com.br",
"minas.com.br",
"minivps.com.br",
"novahost.com.br",
"nuvemhospedagem.com.br",
"nwi.com.br",
"origiweb.com.br",
"porta80.com.br",
"qnax.sh",
"quantivehost.com.br",
"raiozhost.com",
"reselhost.com",
"scriptcase.host",
"secnet.com.br",
"sempihost.com.br",
"servcloud.com.br",
"servermedia.com.br",
"serversp.com",
"servhost.com.br",
"site.com.br",
"sitefacil.com",
"sitehosting.com.br",
"skymail.com.br",
"softhost.com.br",
"speedhost.com.br",
"studioserver.com.br",
"targethost.com.br",
"terraempresas.com.br",
"tucanoweb.com.br",
"turbosite.com.br",
"umbler.com",
"under.com.br",
"universonet.com.br",
"uolhost.uol.com.br",
"virtuaserver.com.br",
"webinhost.com.br",
"webnow.com.br",
"westhost.com.br",
"ycorn.com.br",
"zarphost.com.br",
    ]
    process_domains(eklenen_domain_listesi, klasor_adi, id_klasoru)

def process_tool5():
    klasor_adi = "BigData"
    sonuclar_klasoru = "CheckLog"
    id_klasoru = os.path.join(sonuclar_klasoru, "tr")

    olustur_klasorler(sonuclar_klasoru, id_klasoru)

    eklenen_domain_listesi = [
"ahosting.net",
"alantron.com",
"alastyr.com",
"altinsoft.net",
"asoregister.com",
"atakdomain.com",
"aysima.com",
"birhost.net",
"bogahost.com",
"burtinet.com",
"cenuta.com",
"cliaweb.com",
"cloud.com.tr",
"corelux.com.tr",
"daha.net",
"datafon.net.tr",
"dgnteknoloji.com",
"digiturunc.com",
"dinamohosting.com",
"domainhizmetleri.com",
"ekonomikhost.net",
"enghost.com.tr",
"fibu.com.tr",
"garantiserver.com",
"ghs.net.tr",
"globalnet.com.tr",
"guzel.net.tr",
"hizhosting.com",
"hostajans.com",
"hostavrupa.net",
"hostevi.com",
"hosthink.net",
"hosting.com.tr",
"hostingdunyam.com.tr",
"hostinturkey.com",
"hostixo.com",
"hostlab.com",
"hozzt.com",
"idebil.com",
"ihs.com.tr",
"inetmar.com",
"inkatescil.com.tr",
"interbim.com",
"internetbilisim.net",
"internettescil.com.tr",
"isimtescil.net",
"ixirhost.com",
"karegen.com",
"keyubu.com",
"kmk.net.tr",
"kriweb.com",
"limonhost.net",
"linesis.com",
"lnwservers.com",
"markum.com",
"medyabim.com.tr",
"meric.net.tr",
"modernizmir.net",
"muvhost.com",
"narweb.net",
"natro.com",
"netdirekt.com.tr",
"netinternet.com.tr",
"netiyi.com",
"niobehosting.com",
"odeaweb.com",
"onlinehosting.com.tr",
"ownhost.net",
"parkajans.com.tr",
"pluslayer.com",
"poyrazhosting.com.tr",
"rabisu.com",
"radore.com",
"senkronet.com.tr",
"serverkurma.com",
"sh.com.tr",
"sistemhost.com",
"spd.net.tr",
"sunucu.com.tr",
"sunucucozumleri.com",
"sunucupark.com",
"sunucuturkiye.com",
"tasarimrehberi.com",
"teklan.com.tr",
"turhost.com",
"turkishost.com",
"turknethost.com",
"turkticaret.net",
"uzmantescil.com.tr",
"veganet.com.tr",
"venois.net",
"verigom.com",
"verinomi.com",
"vizyon.net.tr",
"webarisi.com",
"webevi.com",
"webim.com.tr",
"webkur.com",
"webservis.com.tr",
"yesilbeyaz.com.tr",
    ]
    process_domains(eklenen_domain_listesi, klasor_adi, id_klasoru)

def process_tool6():
    klasor_adi = "BigData"
    sonuclar_klasoru = "CheckLog"
    id_klasoru = os.path.join(sonuclar_klasoru, "vn")

    olustur_klasorler(sonuclar_klasoru, id_klasoru)

    eklenen_domain_listesi = [
"123host.vn",
"3ts.vn",
"appvz.com",
"azdigi.com",
"bizmac.com",
"bkhost.vn",
"bkns.vn",
"digistar.vn",
"fsivietnam.com.vn",
"hostingviet.vn",
"hostvn.net",
"hvn.vn",
"inet.vn",
"kdata.vn",
"matbao.net",
"nhanhoa.com",
"onedata.vn",
"pavietnam.vn",
"sieutocviet.com",
"superhost.vn",
"tenten.vn",
"tgs.com.vn",
"thegioiso.cloud",
"tnd.vn",
"vdata.vn",
"vdodata.vn",
"vhost.vn",
"viethosting.com",
"vietnamserver.net",
"vietnetnam.vn",
"vietnix.vn",
"vinahost.vn",
"vinaweb.vn",
"vmms.vn",
"vnetwork.vn",
"vnregistrar.com",
"vnso.vn",
"vsis.net",
    ]
    process_domains(eklenen_domain_listesi, klasor_adi, id_klasoru)

def process_tool7():
    klasor_adi = "BigData"
    sonuclar_klasoru = "CheckLog"
    id_klasoru = os.path.join(sonuclar_klasoru, "ph")

    olustur_klasorler(sonuclar_klasoru, id_klasoru)

    eklenen_domain_listesi = [
"1pesohosting.com",
"alchosting.net",
"bigbytes.net",
"capitanhosting.com",
"cidhosting.net",
"creativeweb.biz",
"digitalpound.net",
"domainwink.com",
"dot.ph",
"gomanilahost.net",
"hosting.ph",
"hostinger.ph",
"ibuild.ph",
"imanila.ph",
"imapwebsolutions.com",
"jdchost.com",
"jollyworkshosting.com",
"needforweb.com",
"philwebservices.com",
"readyspace.com.ph",
"snowweb.net",
"web.com.ph",
"webfocus.ph",
"xtrahosting.net",
"z.com",
"zoom.ph",
    ]
    process_domains(eklenen_domain_listesi, klasor_adi, id_klasoru)

def process_tool8():
    klasor_adi = "BigData"
    sonuclar_klasoru = "CheckLog"
    id_klasoru = os.path.join(sonuclar_klasoru, "bg")

    olustur_klasorler(sonuclar_klasoru, id_klasoru)

    eklenen_domain_listesi = [
"123.bg",
"abscloud.eu",
"alphavps.com",
"belani.host",
"bgocloud.com",
"blueangel.host",
"bullethost.net",
"cbox.biz",
"cloudbalkan.com",
"daticum.com",
"delta.bg",
"dom.bg",
"eurohoster.org",
"here-host.com",
"host-ed.net",
"host.ag",
"host.bg",
"hostbalkan.com",
"hostbulgaria.com",
"hostcoloreurope.com",
"hostline.bg",
"hostplay.com",
"hostzealot.com",
"itldc.com",
"jump.bg",
"motov.net",
"myhost.io",
"neterra.cloud",
"netreact.com",
"ns1.bg",
"offshorededicated.net",
"powerhost.bg",
"qhoster.com",
"rax.bg",
"s3c.bg",
"speedehost.com",
"superbithost.com",
"superhosting.bg",
"theonionhost.com",
"vps.bg",
"vpsag.com",
"webehostin.com",
"wpx.net",
"xenonhost.co",
"zettahost.bg",
"zynoo.com",
    ]
    process_domains(eklenen_domain_listesi, klasor_adi, id_klasoru)

def process_domains(domain_list, klasor_adi, id_klasoru):
    for domain in domain_list:
        bulunan_satirlar = []
        for dosya_adi in os.listdir(klasor_adi):
            dosya_yolu = os.path.join(klasor_adi, dosya_adi)
            try:
                with open(dosya_yolu, 'r', encoding="utf-8", errors="ignore") as dosya:
                    for satir in dosya:
                        if domain in satir and satir.strip() not in bulunan_satirlar:
                            bulunan_satirlar.append(satir.strip())
            except UnicodeDecodeError as e:
                print(f"Error decoding file {dosya_yolu}: {e}")

        if bulunan_satirlar:
            # Mevcut satırları oku
            existing_lines = set()
            try:
                with open(os.path.join(id_klasoru, f'{domain}.txt'), 'r', encoding="utf-8") as existing_file:
                    existing_lines = set(existing_file.read().splitlines())
            except FileNotFoundError:
                pass

            # Yeni özgün satırları ekle
            yeni_satirlar = set(bulunan_satirlar) - existing_lines

            if yeni_satirlar:
                with open(os.path.join(id_klasoru, f'{domain}.txt'), 'a', encoding="utf-8") as dosya:
                    for satir in sorted(yeni_satirlar):  # Alfabetik sıraya göre yaz
                        dosya.write(satir + '\n')
                print(f"{domain}.txt güncellendi.")
            else:
                print(f"{domain} için yeni satır yok.")
        else:
            print(f"{domain} bulunamadı.")

def main():
    print("Hangi işlem yapmak istersiniz?")
    print("1. Tool 1  id ")
    print("2. Tool 2  in")
    print("3. Tool 3  th")
    print("4. Tool 4  br")
    print("5. Tool 5  tr")
    print("6. Tool 6  vn")
    print("7. Tool 7  ph")
    print("8. Tool 8  bg")
    print("9. Her hepsi")

    secim = input("Seçiminizi yapın (1-9): ")

    if secim == "1":
        process_tool1()
    elif secim == "2":
        process_tool2()
    elif secim == "3":
        process_tool3()
    elif secim == "4":
        process_tool4()
    elif secim == "5":
        process_tool5()
    elif secim == "6":
        process_tool6()
    elif secim == "7":
        process_tool7()
    elif secim == "8":
        process_tool8()
    elif secim == "9":
        process_tool1()
        process_tool2()
        process_tool3()
        process_tool4()
        process_tool5()
        process_tool6()
        process_tool7()
        process_tool8()
    else:
        print("Geçersiz seçim. Lütfen 1 ile 9 arasında bir seçim yapın.")

if __name__ == "__main__":
    main()
