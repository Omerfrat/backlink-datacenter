import os

def find_txt_files(directory):
    txt_files = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith('.txt'):
                txt_files.append(os.path.join(root, file))
    return txt_files

def read_and_deduplicate_files(txt_files):
    unique_lines = set()
    for file in txt_files:
        with open(file, 'r', encoding='utf-8') as f:
            for line in f:
                unique_lines.add(line.strip())
    return unique_lines

def read_existing_lines(output_file):
    if os.path.exists(output_file):
        with open(output_file, 'r', encoding='utf-8') as f:
            return set(line.strip() for line in f)
    return set()

def write_to_output_file(output_file, unique_lines):
    existing_lines = read_existing_lines(output_file)
    # Yeni benzersiz satırları mevcut olanlarla birleştir ve sadece benzersiz olanları al
    new_unique_lines = unique_lines - existing_lines

    if new_unique_lines:  # Eğer yeni benzersiz satırlar varsa yaz
        with open(output_file, 'a', encoding='utf-8') as f:
            for line in sorted(new_unique_lines):
                f.write(line + '\n')

def main():
    input_directory = 'HostLog'  # Klasör yolu buraya gelecek
    output_file = 'BigData/BigData.txt'
    
    txt_files = find_txt_files(input_directory)
    unique_lines = read_and_deduplicate_files(txt_files)
    write_to_output_file(output_file, unique_lines)

if __name__ == "__main__":
    main()
