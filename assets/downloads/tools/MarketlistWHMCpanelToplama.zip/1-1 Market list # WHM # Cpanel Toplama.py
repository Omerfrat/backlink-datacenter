import os

def create_results_folder(folder_name):
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)

def tool1():
    klasor_adi = "Files"
    sonuclar_klasoru = "Market-WHM-CPANEL"
    create_results_folder(sonuclar_klasoru)

    eklenen_domain_listesi = [
        "sellex.biz", "sellex.is", "sellex.lu", "sellex.xyz",
        "odinshop.io", "odinshop.se", "freshtools.to", "freshtools.net",
        "freshtools.pw", "freshtools.is", "freshtools.sk", "freshtools.in",
        "freshtools.co", "freshtools.sh", "orvx.pw", "spamx.net",
        "spamx.to", "spamx.pw", "spamx.io", "w0rm.pw", "w0rm.to"
    ]

    for domain in eklenen_domain_listesi:
        bulunan_satirlar = set()
        for dosya_adi in os.listdir(klasor_adi):
            dosya_yolu = os.path.join(klasor_adi, dosya_adi)
            try:
                with open(dosya_yolu, 'r', encoding="latin1", errors="ignore") as dosya:
                    for satir in dosya:
                        if domain in satir:
                            bulunan_satirlar.add(satir.strip())
            except Exception as e:
                print(f"Unexpected error with file {dosya_yolu}: {e}")

        if bulunan_satirlar:
            with open(os.path.join(sonuclar_klasoru, f'{domain}.txt'), 'w', encoding="utf-8") as dosya:
                for satir in sorted(bulunan_satirlar):
                    dosya.write(satir + '\n')
            print(f"{domain}.txt güncellendi.")
        else:
            print(f"{domain} bulunamadı.")

def tool2():
    ana_klasor = "Files"
    sonuc_klasoru = "Market-WHM-CPANEL"
    hedef_dosya_adi = "2087.txt"
    
    eslesen_kelimeler = [
        " 2087|", " 2087/|", " 2087:", " 2087/:",
        ":2087/|", ":2087|", ":2087:", ":2087/:"
    ]

    hedef_dosya_yolu = os.path.join(sonuc_klasoru, hedef_dosya_adi)
    create_results_folder(sonuc_klasoru)

    for dosya_adı in os.listdir(ana_klasor):
        dosya_yolu = os.path.join(ana_klasor, dosya_adı)
        if os.path.isfile(dosya_yolu) and dosya_adı.endswith(".txt"):
            try:
                with open(dosya_yolu, "r", encoding="latin1", errors="ignore") as dosya_okuyucu:
                    bulunan_satirlar = set()
                    for satır in dosya_okuyucu:
                        for kelime in eslesen_kelimeler:
                            if kelime in satır:
                                bulunan_satirlar.add(satır.strip())
                                break
                    if bulunan_satirlar:
                        with open(hedef_dosya_yolu, "a", encoding="utf-8") as hedef_dosya:
                            for satir in sorted(bulunan_satirlar):
                                hedef_dosya.write(satir + '\n')
            except Exception as e:
                print(f"Unexpected error with file {dosya_yolu}: {e}")

def tool3():
    ana_klasor = "Files"
    sonuc_klasoru = "Market-WHM-CPANEL"
    hedef_dosya_adi = "2083.txt"

    eslesen_kelimeler = [
        " 2083|", " 2083/|", " 2083:", " 2083/:",
        ":2083|", ":2083/|", ":2083:", ":2083/:",
        ":2083/cpsess", " 2083/cpsess", " 2082|",
        " 2082/|", " 2082:", ":2082|", ":2082/|",
        ":2082:", ":2082/cpsess", " 2082/cpsess"
    ]

    hedef_dosya_yolu = os.path.join(sonuc_klasoru, hedef_dosya_adi)
    create_results_folder(sonuc_klasoru)

    for dosya_adı in os.listdir(ana_klasor):
        dosya_yolu = os.path.join(ana_klasor, dosya_adı)
        if os.path.isfile(dosya_yolu) and dosya_adı.endswith(".txt"):
            try:
                with open(dosya_yolu, "r", encoding="latin1", errors="ignore") as dosya_okuyucu:
                    bulunan_satirlar = set()
                    for satır in dosya_okuyucu:
                        for kelime in eslesen_kelimeler:
                            if kelime in satır:
                                bulunan_satirlar.add(satır.strip())
                                break
                    if bulunan_satirlar:
                        with open(hedef_dosya_yolu, "a", encoding="utf-8") as hedef_dosya:
                            for satir in sorted(bulunan_satirlar):
                                hedef_dosya.write(satir + '\n')
            except Exception as e:
                print(f"Unexpected error with file {dosya_yolu}: {e}")

def run_all_tools():
    tool1()
    tool2()
    tool3()

def main():
    print("Bir işlem seçin:")
    print("1: Tool 1")
    print("2: Tool 2")
    print("3: Tool 3")
    print("4: Hepsini çalıştır")
    choice = input("Seçiminizi yapınız (1/2/3/4): ")

    if choice == '1':
        tool1()
    elif choice == '2':
        tool2()
    elif choice == '3':
        tool3()
    elif choice == '4':
        run_all_tools()
    else:
        print("Geçersiz seçim.")

if __name__ == "__main__":
    main()
