import os

# Klasör isimleri
klasor_adi = "DomainList"
sonuclar_klasoru = "HostLog"

# Sonuçlar klasörünü oluştur
if not os.path.exists(sonuclar_klasoru):
    os.makedirs(sonuclar_klasoru)

# Domain listesi için dökümanları oku
domain_dosyaları = [f for f in os.listdir(klasor_adi) if f.endswith('.txt')]
domain_dosyaları.sort()  # Alfabetik sıralama

# Kullanıcıdan seçim al
print("Lütfen aramak istediğiniz domain listesini seçin:")
for idx, dosya in enumerate(domain_dosyaları):
    print(f"{idx + 1}. {dosya[:-4]}")  # Dosya uzantısını atla

secim = int(input("Seçiminizi yapın (numara ile): ")) - 1
if secim < 0 or secim >= len(domain_dosyaları):
    print("Geçersiz seçim.")
else:
    Secilen_dosya = domain_dosyaları[secim]
    print(f"{Secilen_dosya} dosyası seçildi.")

    # Seçilen dosyadaki domainleri oku
    with open(os.path.join(klasor_adi, Secilen_dosya), 'r', encoding="utf-8", errors="ignore") as f:
        eklenen_domain_listesi = [line.strip() for line in f]

    for domain in eklenen_domain_listesi:
        bulunan_satirlar = set()  # Set kullanarak özgün satırları sakla
        
        # Domain'e ait satırları bul
        for dosya_adi in os.listdir("Files"):
            dosya_yolu = os.path.join("Files", dosya_adi)
            try:
                with open(dosya_yolu, 'r', encoding="utf-8", errors="ignore") as dosya:
                    for satir in dosya:
                        if domain in satir:
                            bulunan_satirlar.add(satir.strip())  # Set'e ekleyerek özgün tut
            except UnicodeDecodeError as e:
                print(f"Error decoding file {dosya_yolu}: {e}")

        # Dosya yolunu oluştur
        dosya_yolu = os.path.join(sonuclar_klasoru, f'{domain}.txt')

        # Dosyayı oku ve mevcut satırları içeren bir set oluştur
        mevcut_satirlar = set()
        if os.path.exists(dosya_yolu):
            with open(dosya_yolu, 'r', encoding="utf-8") as dosya:
                mevcut_satirlar = set(dosya.read().splitlines())

        # Yeni bulunan satırları mevcut olanlarla birleştir
        tum_satirlar = mevcut_satirlar.union(bulunan_satirlar)

        if tum_satirlar:
            # Özgün satırları alfabetik olarak sıralama
            sorted_lines = sorted(tum_satirlar)

            # Dosyayı yazma modunda aç ve içeriği güncelle
            with open(dosya_yolu, 'w', encoding="utf-8") as dosya:
                for satir in sorted_lines:
                    dosya.write(satir + '\n')

            print(f"{domain}.txt güncellendi.")
        else:
            print(f"{domain} bulunamadı.")

print("İşlem tamamlandı.")
