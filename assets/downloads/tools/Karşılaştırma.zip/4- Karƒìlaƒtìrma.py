import os

# CheckLog ve UsedLog dizinlerinin yollarını tanımla
checklog_dir = 'CheckLog'
usedlog_dir = 'UsedLog'
newhostinglogin_dir = 'NewHostingLogin'
newhostinglogin_file = os.path.join(newhostinglogin_dir, 'NewHostingLogin.txt')

# NewHostingLogin dizininin var olduğundan emin ol
os.makedirs(newhostinglogin_dir, exist_ok=True)

# Bir dizindeki tüm .txt dosyalarından tüm satırları almak için bir fonksiyon
def read_logs_from_directory(directory):
    logs = {}
    print(f"{directory} dizini okunuyor...")
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith('.txt'):
                relative_path = os.path.relpath(root, directory)  # Dosyanın klasör yapısına göre yolunu al
                if relative_path not in logs:
                    logs[relative_path] = {}
                try:
                    with open(os.path.join(root, file), 'r', encoding='utf-8') as f:
                        logs[relative_path][file] = set(f.read().splitlines())
                except UnicodeDecodeError:
                    print(f"Hata: {file} dosyası okunamadı. Kodlama hatası.")
    print(f"{directory} dizini okuma işlemi tamamlandı.")
    return logs

# Logları bir dosyaya yazmak için bir fonksiyon
def write_logs_to_file(logs, filepath, mode='w'):
    print(f"{filepath} dosyasına loglar yazılıyor...")
    with open(filepath, mode, encoding='utf-8') as f:
        for log in sorted(logs):  # Logları alfabetik olarak sıralama
            f.write(log + '\n')
    print(f"{filepath} dosyasına log yazma işlemi tamamlandı.")

# CheckLog ve UsedLog dizinlerindeki logları oku
print("CheckLog ve UsedLog dizinlerindeki loglar okunuyor...")
checklog_logs = read_logs_from_directory(checklog_dir)
usedlog_logs = read_logs_from_directory(usedlog_dir)

# Her CheckLog klasörü ve dosyası için, UsedLog'da olmayan logları belirle ve kaydet
new_logs = set()
print("Yeni loglar belirleniyor ve kayıt işlemi başlıyor...")
for folder, files in checklog_logs.items():
    for file, logs in files.items():
        used_logs = usedlog_logs.get(folder, {}).get(file, set())
        unique_logs = logs - used_logs
        if unique_logs:
            # NewHostingLogin.txt dosyasına yeni logları yaz (üzerine yazarak)
            new_logs.update(unique_logs)

            # UsedLog dizininde ilgili klasör ve dosyayı oluştur ve logları ekle
            usedlog_folder_path = os.path.join(usedlog_dir, folder)
            os.makedirs(usedlog_folder_path, exist_ok=True)  # Klasörü oluştur (varsa sorun çıkarmaz)
            usedlog_file_path = os.path.join(usedlog_folder_path, file)
            write_logs_to_file(unique_logs, usedlog_file_path, mode='a')  # Dosyayı korur ve yeni logları ekler

# NewHostingLogin.txt dosyasına yeni logları yaz, eski içeriği siler
write_logs_to_file(new_logs, newhostinglogin_file)

print("İşlem tamamlandı. Yeni loglar NewHostingLogin.txt ve UsedLog dizinlerine kaydedildi.")
