import os

def format_url(input_url, change_port=False):
    if not input_url.startswith(('http://', 'https://')):
        input_url = f"http://{input_url}"
    parts = input_url.split(':')
    if len(parts) < 3:
        return ""

    try:
        port = parts[2].split('/')[0]
        username = parts[-2]
        password = parts[-1]
        domain = parts[1]

        if change_port and port == "2083":
            port = "2087"

        return f"{parts[0]}:{domain}:{port}|{username}|{password}"
    except IndexError:
        return ""

def process_input(input_list, change_port=False):
    filtered_lines = []
    for line in input_list:
        line = line.strip()
        formatted_url = format_url(line, change_port)
        if formatted_url:
            filtered_lines.append(formatted_url)
    return filtered_lines

def write_to_file(output_list, output_file):
    os.makedirs(os.path.dirname(output_file), exist_ok=True)

    try:
        if os.path.exists(output_file):
            with open(output_file, "r", encoding="utf-8") as file:
                existing_lines = set(file.read().splitlines())
        else:
            existing_lines = set()

        new_lines = set(output_list)
        combined_lines = existing_lines.union(new_lines)

        sorted_lines = sorted(combined_lines)
        with open(output_file, "w", encoding="utf-8") as file:
            for line in sorted_lines:
                if '2082/cpsess' not in line and '2083/cpsess' not in line:
                    file.write(line + "\n")
    except Exception as e:
        print(f"Hata oluştu: {e}")

def main():
    print("Hangi tool'ı kullanmak istersiniz?")
    print("1 - Tool 1 (2083.txt için)")
    print("2 - Tool 2 (2087.txt için)")
    print("3 - Her ikisini birden çalıştır\n")
    
    choice = input("Seçiminizi yapın (1/2/3): ").strip()
    
    input_lists = []
    output_files = []
    change_ports = []

    if choice == '1':
        input_lists.append("Market-WHM-CPANEL/2083.txt")
        output_files.append("Cpanel-Whm/Temiz2083.txt")
        change_ports.append(False)
    elif choice == '2':
        input_lists.append("Market-WHM-CPANEL/2087.txt")
        output_files.append("Cpanel-Whm/Temiz2087.txt")
        change_ports.append(True)
    elif choice == '3':
        input_lists.append("Market-WHM-CPANEL/2083.txt")
        output_files.append("Cpanel-Whm/Temiz2083.txt")
        change_ports.append(False)
        
        input_lists.append("Market-WHM-CPANEL/2087.txt")
        output_files.append("Cpanel-Whm/Temiz2087.txt")
        change_ports.append(True)
    else:
        print("Geçersiz seçim. Programdan çıkılıyor.")
        return

    for file_path, output_file, change_port in zip(input_lists, output_files, change_ports):
        try:
            with open(file_path, "r", encoding="utf-8") as file:
                input_list = [line.strip() for line in file.readlines()]
        except FileNotFoundError:
            print(f"Belirtilen dosya bulunamadı: {file_path}")
            continue
        except Exception as e:
            print(f"Dosya okuma hatası: {e}")
            continue

        processed_list = process_input(input_list, change_port)

        if not processed_list:
            print(f"{output_file} için uygun URL bulunamadı.")
            continue

        write_to_file(processed_list, output_file)
        print(f"Sonuçlar '{output_file}' dosyasına yazıldı.")

if __name__ == "__main__":
    main()
