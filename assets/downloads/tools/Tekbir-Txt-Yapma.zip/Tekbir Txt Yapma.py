import os

def find_txt_files(directory):
    """Verilen dizindeki tüm .txt dosyalarını bulur."""
    txt_files = []
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith('.txt'):
                txt_files.append(os.path.join(root, file))
    return txt_files

def read_and_deduplicate_files(txt_files):
    """Her dosyadaki benzersiz satırları bir küme içine alır."""
    unique_lines = set()
    for file in txt_files:
        with open(file, 'r', encoding='utf-8') as f:
            for line in f:
                unique_lines.add(line.strip())
    return unique_lines

def write_to_output_file(output_file, unique_lines):
    """Benzersiz satırları alfabetik sıraya göre sonuç dosyasına yazar."""
    with open(output_file, 'w', encoding='utf-8') as f:
        for line in sorted(unique_lines):
            f.write(line + '\n')

def main():
    """Ana işlev: Dosyaları bulur, okur, benzersizleştirir ve sonuç dosyasını yazar."""
    input_directory = 'CheckLog'  # Giriş dizini
    output_directory = 'Toplanmış txt '  # Çıktı klasörü
    output_file = os.path.join(output_directory, 'Toplanmış txt.txt')  # Çıktı dosyası yolu

    # Çıktı klasörünü oluştur
    os.makedirs(output_directory, exist_ok=True)
    
    # Dosyaları bul ve benzersiz satırları oku
    txt_files = find_txt_files(input_directory)
    unique_lines = read_and_deduplicate_files(txt_files)
    
    # Sonuçları dosyaya yaz
    write_to_output_file(output_file, unique_lines)

if __name__ == "__main__":
    main()
